// Name: Anurag
// Roll no: 1601CS05

#include <bits/stdc++.h>
using namespace std;

int main()
{
	int num = 3;
	double a;

	for (a = 0.0; a <= 20; a = a + 0.5)
	{
        cout<<a<<"\n";

	}



	return 0;
}
