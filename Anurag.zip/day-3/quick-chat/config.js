var config = {};

config.connectionsLimit = 5;
config.block = ["::1", "172.16.1.12", "172.16.1.334"];

module.exports = config;
