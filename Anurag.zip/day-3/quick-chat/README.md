# quick-chat
A quick chat application.

# How to run
 1. Go to root folder and run `npm install`
 2. Run `node server.js`
 3. Visit port `http://localhost:4000` in browser.
